module.exports=[19781,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_api_auth_logout_route_actions_01gqv29.js.map