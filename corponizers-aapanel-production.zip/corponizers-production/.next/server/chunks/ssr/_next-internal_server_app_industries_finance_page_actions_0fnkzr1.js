module.exports=[89832,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_finance_page_actions_0fnkzr1.js.map