module.exports=[14686,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_energy_page_actions_0bnp6nj.js.map