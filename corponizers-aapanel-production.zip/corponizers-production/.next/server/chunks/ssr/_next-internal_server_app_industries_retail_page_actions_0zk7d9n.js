module.exports=[19660,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_retail_page_actions_0zk7d9n.js.map