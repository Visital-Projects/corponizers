module.exports=[79029,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_manufacturing_page_actions_185ebmy.js.map