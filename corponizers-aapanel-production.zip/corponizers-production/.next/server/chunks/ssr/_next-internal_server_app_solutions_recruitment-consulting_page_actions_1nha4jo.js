module.exports=[97324,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solutions_recruitment-consulting_page_actions_1nha4jo.js.map