module.exports=[81577,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_education_page_actions_1_t6lra.js.map