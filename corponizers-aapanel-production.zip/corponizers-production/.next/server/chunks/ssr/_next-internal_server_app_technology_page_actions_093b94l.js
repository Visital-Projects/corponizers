module.exports=[97061,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_technology_page_actions_093b94l.js.map