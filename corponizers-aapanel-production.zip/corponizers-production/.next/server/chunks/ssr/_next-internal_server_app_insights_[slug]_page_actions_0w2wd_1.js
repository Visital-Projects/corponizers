module.exports=[3485,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_insights_%5Bslug%5D_page_actions_0w2wd_1.js.map