module.exports=[10005,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_rpo-solutions_page_actions_1mpebhr.js.map