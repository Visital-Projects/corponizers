module.exports=[61561,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solutions_contract-staffing_page_actions_1q9vq4h.js.map