module.exports=[54513,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_steel_page_actions_02yw1j7.js.map