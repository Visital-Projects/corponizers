module.exports=[78375,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solutions_global-mobility_page_actions_1dhe8ix.js.map