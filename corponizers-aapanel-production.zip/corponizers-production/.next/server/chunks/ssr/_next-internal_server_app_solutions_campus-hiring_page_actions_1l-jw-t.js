module.exports=[77359,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solutions_campus-hiring_page_actions_1l-jw-t.js.map