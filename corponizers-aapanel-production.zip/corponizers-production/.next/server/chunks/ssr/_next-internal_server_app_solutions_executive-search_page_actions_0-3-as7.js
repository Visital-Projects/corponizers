module.exports=[785,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solutions_executive-search_page_actions_0-3-as7.js.map