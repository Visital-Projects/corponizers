module.exports=[79532,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_industries_mining_page_actions_1apwhyg.js.map