module.exports=[25507,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solutions_permanent-hiring_page_actions_0v68owt.js.map