:HL["/_next/static/chunks/24zajq831_ntf.css","style"]
:HL["/_next/static/chunks/2p8cumtucwxqu.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"industries","param":null,"prefetchHints":4160,"slots":{"children":{"name":"retail","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"i65NRXHwks2zmCiU_l4zb"}
