:HL["/_next/static/chunks/24zajq831_ntf.css","style"]
:HL["/_next/static/chunks/2p8cumtucwxqu.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"i65NRXHwks2zmCiU_l4zb"}
