var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/admin/api/enquiries/route.js")
R.c("server/chunks/[root-of-the-server]__0n1n4i8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__19w939q._.js")
R.c("server/chunks/_next-internal_server_app_admin_api_enquiries_route_actions_1m0bz64.js")
R.m(23907)
module.exports=R.m(23907).exports
