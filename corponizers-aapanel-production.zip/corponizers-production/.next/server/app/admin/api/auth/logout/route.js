var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/admin/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0srtc3n._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__19w939q._.js")
R.c("server/chunks/_next-internal_server_app_admin_api_auth_logout_route_actions_01gqv29.js")
R.m(34095)
module.exports=R.m(34095).exports
