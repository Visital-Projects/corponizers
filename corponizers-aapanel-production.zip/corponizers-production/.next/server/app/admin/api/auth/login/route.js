var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/admin/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__1n6vjkg._.js")
R.c("server/chunks/[root-of-the-server]__19w939q._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_admin_api_auth_login_route_actions_1s7-5yf.js")
R.m(3362)
module.exports=R.m(3362).exports
