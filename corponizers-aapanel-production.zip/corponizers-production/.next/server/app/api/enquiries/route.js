var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/enquiries/route.js")
R.c("server/chunks/[root-of-the-server]__1x3x6fl._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_enquiries_route_actions_184844g.js")
R.m(80836)
module.exports=R.m(80836).exports
