var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/blogs/route.js")
R.c("server/chunks/[root-of-the-server]__1bwnrit._.js")
R.c("server/chunks/_1xjwrg2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/[root-of-the-server]__19w939q._.js")
R.c("server/chunks/_next-internal_server_app_api_blogs_route_actions_1c98_gh.js")
R.m(65398)
module.exports=R.m(65398).exports
