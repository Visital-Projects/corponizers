var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/newsletter/route.js")
R.c("server/chunks/[root-of-the-server]__0l2-ie-._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_newsletter_route_actions_0w29l-i.js")
R.m(81233)
module.exports=R.m(81233).exports
